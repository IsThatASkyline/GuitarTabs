async def get_main(**_):

    return {
        "username": "Енотик",
    }
