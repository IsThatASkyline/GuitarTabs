from pydantic import BaseModel


class ApiError(BaseModel):
    pass
