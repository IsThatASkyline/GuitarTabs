from sqlalchemy.orm import DeclarativeBase


class BaseAlchemyModels(DeclarativeBase):
    pass
