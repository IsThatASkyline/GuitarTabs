class AppException(BaseException):
    """Base application exception"""

    pass
